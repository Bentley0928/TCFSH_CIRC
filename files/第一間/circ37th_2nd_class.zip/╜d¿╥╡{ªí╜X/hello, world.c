#include <stdio.h>
int main()
{
    puts("hello, world");
    return 0;
}
