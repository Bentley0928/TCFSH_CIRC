/**
 * file:   0_hello_world.c
 * author: williamlin
 * date:   08/25/2019
 */

#include <stdio.h>​
​
int main()​
{​
    printf("hello, world\n");​
    return 0;​
}

/**
 * example_input:  none
 * example_output: 
 *   hello, world
 */