/**
 * file:   1_getchar_putchar.c
 * author: williamlin
 * date:   08/25/2019
 */

#include<stdio.h>

int main(void)
{
	char c;
	c = getchar();
	putchar(c);
	return 0;
}

/**
 * example_input:
 *   a
 * example_output:
 *   a
 */