/**
 * file:   2_gets_puts.c
   author: nevikw39
   date:   08/25/2019
 */

#include<stdio.h>

int main(void)
{
	char str[80];
	gets(str);
	puts(str);
	return 0;
}

/**
 * example_input:
 *   circ
 * example_output:
 *   circ
 */