# 中一中電研社第一次社課範例程式碼目錄
0. hello, world                       ◎Green Judge 題目：a001
## IO                                 ◎Green Judge 題目：a002, a003, a004                                 　
1. getchar(), putchar() 
2. gets(), puts()
3. scanf(), printf()                  
4. escape sequences                    
5. ANSI Color Code
## Size & Range                       ◎Green Judge 題目：a008
6. integer
7. float
8. float
## Operator                           ◎Green Judge 題目：a005, a006, a007, a009, a010
9. arithmetic                         
10. type conversion
11. assignment
12. relation
